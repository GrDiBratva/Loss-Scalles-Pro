// ===== LOSS SCALLES - ROBLOX KOD DOLDURUCU =====

console.log('[LS Roblox] Hazir...');

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action === 'kodu_doldur') {
        console.log('[LS Roblox] Kod dolduruluyor:', request.kod);
        
        // 2FA input kutusunu bul
        const input = document.querySelector('input[name="code"]') || 
                       document.querySelector('input[type="text"]') ||
                       document.querySelector('.two-step-verification-code-input') ||
                       document.querySelector('input[placeholder*="kod"]') ||
                       document.querySelector('input[placeholder*="code"]');
        
        if (input) {
            input.value = request.kod;
            input.dispatchEvent(new Event('input', {bubbles: true}));
            input.dispatchEvent(new Event('change', {bubbles: true}));
            
            // Submit butonuna bas
            setTimeout(() => {
                const buton = document.querySelector('button[type="submit"]') || 
                              document.querySelector('.submit-button') ||
                              document.querySelector('button:contains("Doğrula")') ||
                              document.querySelector('button:contains("Verify")');
                if (buton) buton.click();
            }, 500);
            
            console.log('[LS Roblox] Kod girildi ve submit edildi!');
        } else {
            console.log('[LS Roblox] Input kutusu bulunamadi.');
        }
    }
});