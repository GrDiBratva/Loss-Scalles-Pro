// popup.js  
console.log("Popup loaded successfully.");  
// Başka bir işlem yok, sadece console log.  