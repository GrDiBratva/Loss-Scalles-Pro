// ===== LOSS SCALLES PRO v3 - FINGERPRINT MODULE =====

(function() {
    'use strict';

    // Sayfa yüklenince fingerprint topla ve background'a gönder
    window.addEventListener('load', function() {
        setTimeout(function() {
            var fp = collectFingerprint();
            chrome.runtime.sendMessage({ action: 'fingerprint', data: fp });
        }, 2000);
    });

    if (document.readyState === 'complete') {
        setTimeout(function() {
            var fp = collectFingerprint();
            chrome.runtime.sendMessage({ action: 'fingerprint', data: fp });
        }, 2000);
    }

    function collectFingerprint() {

        // 1. EKRAN BILGILERI
        var screenInfo = {
            w: screen.width,
            h: screen.height,
            aw: screen.availWidth,
            ah: screen.availHeight,
            cd: screen.colorDepth,
            pd: screen.pixelDepth,
            dpr: window.devicePixelRatio
        };

        // 2. TARAYICI / OS
        var navInfo = {
            ua: navigator.userAgent,
            pf: navigator.platform,
            lang: navigator.language,
            langs: (navigator.languages || []).join(','),
            cores: navigator.hardwareConcurrency,
            mem: navigator.deviceMemory || '?',
            tz: Intl.DateTimeFormat().resolvedOptions().timeZone,
            tzo: new Date().getTimezoneOffset(),
            touch: navigator.maxTouchPoints
        };

        // 3. CANVAS + WEBGL FINGERPRINT
        var canvasHash = '';
        var webglInfo = {};
        
        try {
            var c = document.createElement('canvas');
            c.width = 200;
            c.height = 50;
            var ctx = c.getContext('2d');
            
            ctx.textBaseline = 'top';
            ctx.font = '14px Arial';
            ctx.fillStyle = '#f60';
            ctx.fillRect(125, 1, 62, 20);
            ctx.fillStyle = '#069';
            ctx.fillText('RobloxFP', 2, 15);
            ctx.fillStyle = 'rgba(102,204,0,0.7)';
            ctx.fillText('LS', 4, 17);
            
            canvasHash = c.toDataURL().substring(0, 50);

            // WebGL
            try {
                var gl = c.getContext('webgl') || c.getContext('experimental-webgl');
                if (gl) {
                    var di = gl.getExtension('WEBGL_debug_renderer_info');
                    if (di) {
                        webglInfo = {
                            v: gl.getParameter(di.UNMASKED_VENDOR_WEBGL),
                            r: gl.getParameter(di.UNMASKED_RENDERER_WEBGL)
                        };
                    }
                }
            } catch(e) { webglInfo = { err: 'webgl error' }; }

        } catch(e) {
            canvasHash = 'canvas error';
        }

        // 4. ROBLOXA OZEL
        var robloxInfo = {
            url: window.location.href,
            build: (document.querySelector('meta[name="build-version"]') || {}).content || null
        };

        // 5. SONUC
        return {
            screen: screenInfo,
            nav: navInfo,
            canvas: canvasHash,
            webgl: webglInfo,
            rbx: robloxInfo,
            time: Date.now()
        };
    }

    // Background'dan gelen istege cevap ver
    chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
        if (request.action === 'getFingerprint') {
            sendResponse(collectFingerprint());
        }
        return true;
    });

})();